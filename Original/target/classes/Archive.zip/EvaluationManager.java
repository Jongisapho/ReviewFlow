import java.util.*;

public class EvaluationManager {
    Database db;
    double average;
    int isAccepted;  // 0 = rejected, 1 = accepted, 2 = revision
    NotificationService notificationService;
    List<Reviewer> reviewers;

    private static final double ACCEPT_THRESHOLD = 7.0;
    private static final double REJECT_THRESHOLD = 4.0;
    private static final double CONSENSUS_TOLERANCE = 2.0;

    public EvaluationManager(Database db){
        this.db = db;
        notificationService = new NotificationService();
        reviewers = new ArrayList<>();
    }

    public void startEvaluation(List<Reviewer> reviewerList) {
        this.reviewers = reviewerList;
        for (Reviewer reviewer : reviewerList) {
            db.saveScore(reviewer);
        }
        average = calculateAverage();
        checkConsensus();
        isAccepted = applyRules();
        if (isAccepted == 1) {
            notificationService.notifyAcceptance();
        } else if (isAccepted == 0) {
            notificationService.notifyRejection();
        } else if (isAccepted == 2) {
            notificationService.notifyRevision();
        }
    }

    public double calculateAverage() {
        if (reviewers.isEmpty()) return 0.0;
        double sum = 0;
        for (Reviewer reviewer : reviewers) {
            sum += reviewer.score;
        }
        average = sum / reviewers.size();
        System.out.println("Average score: " + average);
        return average;
    }

    public boolean checkConsensus() {
        if (reviewers.isEmpty()) return true;
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        for (Reviewer reviewer : reviewers) {
            if (reviewer.score < min) min = reviewer.score;
            if (reviewer.score > max) max = reviewer.score;
        }
        boolean consensus = (max - min) <= CONSENSUS_TOLERANCE;
        System.out.println("Consensus reached: " + consensus);
        return consensus;
    }

    public int applyRules() {
        if (average >= ACCEPT_THRESHOLD) {
            return 1; // accepted
        } else if (average < REJECT_THRESHOLD) {
            return 0; // rejected
        } else {
            return 2; // revision
        }
    }

    public void submitScore(double score) {
        System.out.println("Score received by EvaluationManager: " + score);
    }
}
