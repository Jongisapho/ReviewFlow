
public class Reviewer {
    EvaluationManager evaluationManager ;
    double score;
    boolean hasConflict;
    int currentWorkload;
    

    public Reviewer(Database db){
        evaluationManager = new EvaluationManager(db);
    }

    public void assignReview() {
        currentWorkload++;
        System.out.println("Review assigned. Current workload: " + currentWorkload);
    }

    public void submitScore(double score) {
        this.score = score;
        System.out.println("Score submitted: " + score);
    }
}
