
public class NotificationService {

    public void notifyAcceptance(){
        System.out.print("Accepted");
    }
    public void notifyRejection(){
        System.out.print("Rejected");
    }
    public void notifyRevision(){
        System.out.print("Revision");
    }
}